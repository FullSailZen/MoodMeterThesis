"""
API routes for MoodMeter evidence analysis.
"""
import logging

from typing import Annotated

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    UploadFile as FastAPIUploadFile
)

from openai import OpenAIError

from pydantic import (
    ValidationError,
    WithJsonSchema
)

from sqlalchemy.orm import Session

from app.db.database import get_db

from app.db.models import (
    Business,
    Review,
    ReviewEvidence,
    User
)

from app.schemas.evidence import (
    EvidenceSubmissionResult
)

from app.services.business_verification_service import (
    compare_business_information
)

from app.services.evidence_analysis_service import (
    analyze_evidence
)

from app.services.evidence_evaluation_service import (
    evaluate_transaction_and_product_information
)

from app.services.evidence_file_service import (
    save_and_record_evidence_file
)

from app.services.evidence_storage_service import (
    ALLOWED_IMAGE_TYPES
)

from app.services.moodscore_service import (
    calculate_business_moodscore,
    save_business_moodscore
)

from app.services.product_comparison_service import (
    compare_product_information
)

from app.services.review_embedding_service import (
    generate_embedding_for_eligible_review
)

from app.services.review_evidence_service import (
    create_review_evidence,
    has_duplicate_evidence
)

from app.services.security_service import (
    get_current_user
)

from app.services.sentiment_analysis_service import (
    analyze_review_sentiment
)

from app.services.sentiment_service import (
    save_sentiment_result
)

from app.services.upc_lookup_service import (
    lookup_upc
)

from app.services.verification_service import (
    evaluate_verification,
    save_verification_status
)


MAX_FILE_SIZE = (
    10 * 1024 * 1024
)

EXPECTED_EMBEDDING_DIMENSIONS = 1536


UploadFile = Annotated[
    FastAPIUploadFile,
    WithJsonSchema(
        {
            "type": "string",
            "format": "binary"
        }
    )
]


router = APIRouter(
    prefix="/evidence",
    tags=["Evidence"]
)

logger = logging.getLogger(__name__)

@router.post(
    "/analyze",
    response_model=(
        EvidenceSubmissionResult
    )
)
async def analyze_submitted_evidence(
    review_id: int = Form(...),
    receipt: UploadFile = File(...),
    purchase_images: list[
        UploadFile
    ] = File(...),
    db: Session = Depends(
        get_db
    ),
    current_user: User = Depends(
        get_current_user
    )
) -> EvidenceSubmissionResult:

    review = (
        db.query(Review)
        .filter(
            Review.id == review_id,
            Review.author_id
            == current_user.id
        )
        .first()
    )

    if not review:
        raise HTTPException(
            status_code=404,
            detail="Review not found"
        )

    existing_evidence = (
        db.query(ReviewEvidence)
        .filter(
            ReviewEvidence.review_id
            == review_id
        )
        .first()
    )

    if existing_evidence:
        raise HTTPException(
            status_code=409,
            detail=(
                "Evidence already exists "
                "for this review"
            )
        )

    if receipt.content_type is None:
        raise HTTPException(
            status_code=400,
            detail=(
                "Receipt content type "
                "is missing"
            )
        )

    if (
        receipt.content_type
        not in ALLOWED_IMAGE_TYPES
    ):
        raise HTTPException(
            status_code=400,
            detail=(
                "Unsupported receipt "
                "image type"
            )
        )

    try:
        receipt_bytes = (
            await receipt.read()
        )

    except Exception:
        raise HTTPException(
            status_code=400,
            detail=(
                "MoodMeter could not read "
                "the uploaded receipt image."
            )
        )

    if not receipt_bytes:
        raise HTTPException(
            status_code=400,
            detail=(
                "The uploaded receipt image "
                "is empty."
            )
        )

    if (
        len(receipt_bytes)
        > MAX_FILE_SIZE
    ):
        raise HTTPException(
            status_code=400,
            detail=(
                "Receipt image exceeds "
                "10 MB"
            )
        )

    purchase_files: list[
        tuple[bytes, str]
    ] = []

    for image in purchase_images:

        if image.content_type is None:
            raise HTTPException(
                status_code=400,
                detail=(
                    "Purchase image content "
                    "type is missing"
                )
            )

        if (
            image.content_type
            not in ALLOWED_IMAGE_TYPES
        ):
            raise HTTPException(
                status_code=400,
                detail=(
                    "Unsupported purchase "
                    "image type"
                )
            )

        try:
            image_bytes = (
                await image.read()
            )

        except Exception:
            raise HTTPException(
                status_code=400,
                detail=(
                    "MoodMeter could not read "
                    "one of the uploaded "
                    "purchase images."
                )
            )

        if not image_bytes:
            raise HTTPException(
                status_code=400,
                detail=(
                    "One of the uploaded "
                    "purchase images is empty."
                )
            )

        if (
            len(image_bytes)
            > MAX_FILE_SIZE
        ):
            raise HTTPException(
                status_code=400,
                detail=(
                    "Purchase image exceeds "
                    "10 MB"
                )
            )

        purchase_files.append(
            (
                image_bytes,
                image.content_type
            )
        )

    try:
        result = analyze_evidence(
            receipt_bytes=receipt_bytes,
            receipt_content_type=(
                receipt.content_type
            ),
            purchase_images=(
                purchase_files
            )
        )

    except OpenAIError:
        raise HTTPException(
            status_code=503,
            detail=(
                "MoodMeter could not analyze "
                "the evidence because the AI "
                "service is currently unavailable. "
                "Please try again."
            )
        )

    except (
        ValidationError,
        ValueError,
        TypeError,
        AttributeError
    ):
        raise HTTPException(
            status_code=502,
            detail=(
                "MoodMeter received an invalid "
                "structured response while "
                "analyzing the evidence. "
                "Please try again."
            )
        )

    except Exception:
        raise HTTPException(
            status_code=503,
            detail=(
                "MoodMeter could not complete "
                "the AI evidence analysis. "
                "Please try again."
            )
        )

    try:
        analysis_payload = (
            result.model_dump(
                mode="json"
            )
        )

    except (
        AttributeError,
        TypeError,
        ValueError,
        ValidationError
    ):
        raise HTTPException(
            status_code=502,
            detail=(
                "The AI evidence response "
                "could not be processed because "
                "its structure was invalid."
            )
        )

    required_analysis_fields = (
        "business_name",
        "street_address",
        "city",
        "state",
        "receipt_readable",
        "matched_purchase_item_name",
        "matched_purchase_item_upc",
        "purchase_photo_matches_receipt"
    )

    missing_analysis_fields = [
        field
        for field
        in required_analysis_fields
        if field
        not in analysis_payload
    ]

    if missing_analysis_fields:
        raise HTTPException(
            status_code=502,
            detail=(
                "The AI evidence response was "
                "incomplete and could not be "
                "used safely."
            )
        )

    try:

        review_evidence = (
            create_review_evidence(
                db=db,
                review_id=review.id,
                analysis_result=(
                    analysis_payload
                )
            )
        )

        save_and_record_evidence_file(
            db=db,
            evidence_id=(
                review_evidence.id
            ),
            review_id=review.id,
            file_type="receipt",
            file_bytes=receipt_bytes,
            content_type=(
                receipt.content_type
            )
        )

        for (
            purchase_bytes,
            purchase_content_type
        ) in purchase_files:

            save_and_record_evidence_file(
                db=db,
                evidence_id=(
                    review_evidence.id
                ),
                review_id=review.id,
                file_type="purchase",
                file_bytes=(
                    purchase_bytes
                ),
                content_type=(
                    purchase_content_type
                )
            )

        selected_business = (
            db.query(Business)
            .filter(
                Business.id
                == review.business_id
            )
            .first()
        )

        if selected_business is None:
            raise ValueError(
                "Selected business not found"
            )

        business_comparison = (
            compare_business_information(
                selected_name=(
                    selected_business.name
                ),
                selected_address=(
                    selected_business.address
                ),
                selected_city=(
                    selected_business.city
                ),
                selected_state=(
                    selected_business.state
                ),
                returned_name=(
                    result.business_name
                ),
                returned_address=(
                    result.street_address
                ),
                returned_city=(
                    result.city
                ),
                returned_state=(
                    result.state
                )
            )
        )

        product_comparisons = []

        matched_name = (
            result
            .matched_purchase_item_name
        )

        matched_upc = (
            result
            .matched_purchase_item_upc
        )

        if (
            result
            .purchase_photo_matches_receipt
            is True
        ):

            external_product = None

            if matched_upc:

                try:
                    external_product = (
                        lookup_upc(
                            matched_upc
                        )
                    )

                except Exception:
                    db.rollback()

                    raise HTTPException(
                        status_code=503,
                        detail=(
                            "MoodMeter could not "
                            "retrieve product information "
                            "from UPCitemdb. "
                            "Please try again."
                        )
                    )

            comparison = (
                compare_product_information(
                    receipt_item={
                        "name":
                            matched_name,

                        "upc":
                            matched_upc
                    },
                    external_product=(
                        external_product
                    )
                )
            )

            product_comparisons.append(
                comparison
            )

        evidence_evaluation = (
            evaluate_transaction_and_product_information(
                evidence_result=result,
                product_comparisons=(
                    product_comparisons
                )
            )
        )

        duplicate_evidence = (
            has_duplicate_evidence(
                db=db,
                review_id=review.id
            )
        )

        try:
            verification_result = (
                evaluate_verification(
                    business_match=(
                        business_comparison[
                            "business_match"
                        ]
                    ),
                    product_match=(
                        evidence_evaluation[
                            "product_match"
                        ]
                    ),
                    transaction_date_present=(
                        evidence_evaluation[
                            "transaction_date_present"
                        ]
                    ),
                    duplicate_evidence=(
                        duplicate_evidence
                    ),
                    receipt_readable=(
                        result.receipt_readable
                    )
                )
            )

            if (
                not isinstance(
                    verification_result,
                    dict
                )
                or
                "verified"
                not in verification_result
                or
                "checks"
                not in verification_result
            ):
                raise ValueError(
                    "Invalid verification result"
                )

            save_verification_status(
                db=db,
                review=review,
                verified=(
                    verification_result[
                        "verified"
                    ]
                )
            )

            db.commit()

            db.refresh(
                review
            )

        except Exception:
            db.rollback()

            raise HTTPException(
                status_code=500,
                detail=(
                    "MoodMeter could not complete "
                    "the verification process. "
                    "Please try again."
                )
            )

    except HTTPException:

        db.rollback()

        raise

    except ValueError as error:

        db.rollback()

        raise HTTPException(
            status_code=400,
            detail=str(error)
        )

    except Exception:

        db.rollback()

        raise HTTPException(
            status_code=500,
            detail=(
                "MoodMeter encountered an "
                "unexpected error while processing "
                "the submitted evidence."
            )
        )

    sentiment_status = (
        "not_eligible"
    )

    sentiment_value = None

    sentiment_themes = []

    sentiment_aspects = []

    sentiment_message = (
        "Sentiment analysis is only "
        "performed on verified reviews."
    )

    if (
        review.verification_status
        == "verified"
    ):

        try:

            sentiment_analysis = (
                analyze_review_sentiment(
                    review_text=(
                        review.body
                    ),
                    rating=(
                        review.rating
                    )
                )
            )

            if sentiment_analysis is None:
                raise ValueError(
                    "Sentiment analysis "
                    "returned no result."
                )

            save_sentiment_result(
                db=db,
                review_id=review.id,
                result=(
                    sentiment_analysis
                )
            )

            db.flush()

            review_embedding = (
                generate_embedding_for_eligible_review(
                    db=db,
                    review=review
                )
            )

            if review_embedding is None:
                raise ValueError(
                    "Eligible review embedding "
                    "was not generated."
                )

            if (
                len(review_embedding)
                != EXPECTED_EMBEDDING_DIMENSIONS
            ):
                raise ValueError(
                    "Unexpected embedding dimensions. "
                    f"Expected "
                    f"{EXPECTED_EMBEDDING_DIMENSIONS}, "
                    f"received "
                    f"{len(review_embedding)}."
                )

            moodscore_result = (
                calculate_business_moodscore(
                    db=db,
                    business_id=(
                        review.business_id
                    )
                )
            )

            save_business_moodscore(
                db=db,
                result=(
                    moodscore_result
                )
            )

            db.commit()

            sentiment_status = (
                "analyzed"
            )

            sentiment_value = (
                sentiment_analysis
                .sentiment
            )

            sentiment_themes = (
                sentiment_analysis
                .themes
            )

            sentiment_aspects = [
                aspect.model_dump(
                    mode="json"
                )
                for aspect
                in sentiment_analysis.aspects
            ]

            sentiment_message = (
                "Sentiment analysis completed "
                "successfully. Review embedding "
                f"generated successfully with "
                f"{len(review_embedding)} dimensions."
            )

        except Exception:

            db.rollback()

            sentiment_status = (
                "failed"
            )

            sentiment_value = None

            sentiment_themes = []

            sentiment_aspects = []

            sentiment_message = (
                "The review was processed, but "
                "sentiment analysis could not be "
                "completed. Sentiment information "
                "is temporarily unavailable."
            )

    return EvidenceSubmissionResult(
        review_id=review.id,

        verification_status=(
            review.verification_status
        ),

        analysis=result,

        business_comparison=(
            business_comparison
        ),

        evidence_evaluation=(
            evidence_evaluation
        ),

        duplicate_evidence=(
            duplicate_evidence
        ),

        verification_checks=(
            verification_result[
                "checks"
            ]
        ),

        sentiment_status=(
            sentiment_status
        ),

        sentiment=(
            sentiment_value
        ),

        sentiment_themes=(
            sentiment_themes
        ),

        sentiment_aspects=(
            sentiment_aspects
        ),

        sentiment_message=(
            sentiment_message
        )
    )